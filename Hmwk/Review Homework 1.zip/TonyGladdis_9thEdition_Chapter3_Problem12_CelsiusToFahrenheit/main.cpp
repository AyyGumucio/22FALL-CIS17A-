/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Anthony Gumucio
 *
 * Created on September 11, 2022, 9:11 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    float ctemp;
    float ftemp = 0;
    
    cout << "Enter temperature in Celsius\n";
    cin >> ctemp;
    
    ftemp = (ctemp * 1.8) + 32;
    
    cout << "Temperature in Fahrenheit is: \n"
         << ftemp;
    
    return 0;
}

