/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: antho
 *
 * Created on September 11, 2022, 9:24 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;

/*
 * 
 */

int main() 
{
    const float YEN_PER_DOLLAR = 143.12;
    const float EUROS_PER_DOLLAR = .99;
    
    float Dollar;
    float DtoYen;
    float DtoEuro;
    
    cout << "Enter dollar amount to convert \n";
    cin >> Dollar;
    
    DtoYen = Dollar * YEN_PER_DOLLAR;
    DtoEuro = Dollar * EUROS_PER_DOLLAR;
    
    cout <<setprecision(2) << fixed;
    cout << "Yen amount is: "  << DtoYen << endl;
    cout << "Euro amount is: " << DtoEuro << endl;
    return 0;
}

