/* 
 * File:
 * Author:
 * Date:
 * Purpose:
 * Version:
 */

//System Libraries - Post Here
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries - Post Here

//Global Constants - Post Here
//Only Universal Physics/Math/Conversions found here
//No Global Variables
//Higher Dimension arrays requiring definition prior to prototype only.

//Function Prototypes - Post Here

//Execution Begins Here
int main(int argc, char** argv) {
    //Set random number seed here when needed
    
    //Declare variables or constants here
    //7 characters or less
    float num1;
    float num2; 
    float num3;
    float num4;
    //Initialize or input data here
    cin >> num1 >> num2 >> num3 >> num4;
    //Display initial conditions, headings here
    
    //Process inputs  - map to outputs here
    
    //Format and display outputs here
    cout << showpoint;
    cout << "        " << (int)num1 << "       "  << setprecision(2) <<num1 << "      " << setprecision(3) <<num1 << endl;
    cout << "        " << (int)num2 << "       "  << setprecision(2) <<num2 << "      " << setprecision(3) <<num2 << endl;
    cout << "        " << (int)num3 << "       "  << setprecision(2) <<num3 << "      " << setprecision(3) <<num3 << endl;
    cout << "        " << (int)num4 << "       "  << setprecision(2) <<num4 << "      " << setprecision(3) <<num4;
    //Clean up allocated memory here
    
    //Exit stage left
    return 0;
}