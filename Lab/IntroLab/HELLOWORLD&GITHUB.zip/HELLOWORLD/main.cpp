/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Anthony Gumucio
 *
 * Created on September 7, 2022, 11:34 PM
 */

#include <iostream>

using namespace std;

int main()
{
    cout<<"Hello World";

    return 0;
}

